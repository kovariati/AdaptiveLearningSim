# AdaptiveLearningSim BKT/BKT-F calibration bundle

Status: PASS

- Skills: 20
- Input reference interactions: 2,493,022
- Models per skill: BKT and BKT-F
- Selection: learner-disjoint calibration log loss
- Test split was not used for fitting or model selection.

The Hessian-based standard errors are diagnostic approximations, not final
inferential uncertainty estimates. A learner-cluster bootstrap is required
before manuscript-level confidence intervals are reported.
